package com.example.de.control;

import org.junit.Test;

import static org.junit.Assert.*;

public class UserControlTest {

    @Test
    public void register() {
    }
}