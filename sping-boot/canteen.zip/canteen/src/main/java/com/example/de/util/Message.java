package com.example.de.util;

import lombok.Data;

/**
 * http响应消息
 */
@Data
public class Message {

    private int code;
    private String msg;
    private Object data;

    public static Message createSuc(Object o) {

        return new Message(0, null, o);
    }

    public static Message createErr(String msg) {

        return new Message(-1, msg, null);
    }

    private Message(int code, String msg, Object data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }
}