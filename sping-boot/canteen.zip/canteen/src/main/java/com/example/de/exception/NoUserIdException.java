package com.example.de.exception;

public class NoUserIdException extends RuntimeException {
}
