package com.example.de.config;


import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class ShiroConfig {


    @Bean
    public SecurityManager securityManager(MyShiroRealm myRealm){
        DefaultWebSecurityManager defaultWebSecurityManager=new DefaultWebSecurityManager();

        defaultWebSecurityManager.setRealm(myRealm);
        return defaultWebSecurityManager;

    }

    //最终用这个bean返回的对象来完成我们的认证和拦截
    @Bean
    public MyShiroRealm myRealm(){
        MyShiroRealm myRealm=new MyShiroRealm();
        return myRealm;
    }

    //配置shiro的过滤器bean ,规则的拦截
    @Bean
    public ShiroFilterFactoryBean shiroFilterFactoryBean(SecurityManager securityManager){
        ShiroFilterFactoryBean shiroFilterFactoryBean=new ShiroFilterFactoryBean();
        shiroFilterFactoryBean.setSecurityManager( securityManager);

        Map<String,String> map = new HashMap<String, String>();
        //登出
        map.put("/logout","logout");
        //登录
        map.put("/CRUD/login", "anon");



//        map.put("/CRUD/**", "anon");
//
//        //对所有用户认证
//        map.put("/USER/**","user");
//
//        shiroFilterFactoryBean.setLoginUrl("/login");
//        //首页
//        shiroFilterFactoryBean.setSuccessUrl("/index");
//        //错误页面，认证不通过跳转
//        shiroFilterFactoryBean.setUnauthorizedUrl("/error");
        shiroFilterFactoryBean.setFilterChainDefinitionMap(map);
        return shiroFilterFactoryBean;

    }
}
