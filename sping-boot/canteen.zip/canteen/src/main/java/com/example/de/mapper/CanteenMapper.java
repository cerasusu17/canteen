package com.example.de.mapper;


import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;



import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface CanteenMapper {
    @Select("SELECT * FROM dishes where type=#{type}")
    List<Map<String, Object>> findDishes(int type);

    @Select("SELECT id FROM dishes where type=#{type}")
    List<Integer> findDishesId(int type);

    @Select("SELECT * FROM dishes where id=#{id}")
    Map<String,Object>findDishesInformation(int id);

    @Insert("Insert into `order` (id,user_number,time,state,price) values (#{id},#{user_number},#{time},#{state},#{price})")
    Integer insertOrder(Integer id,String user_number, String time, String state,Double price);

    @Select("Select count(*) from `order`")
    Integer selectCount();

    @Insert("Insert into order_dishes_number (order_id,dishes_id,dishes_count) values (#{order_id},#{dishes_id},#{dishes_count})")
    Integer insertOrderDishes(Integer order_id,Integer dishes_id,Integer dishes_count);

    @Select("Select price from dishes where id=#{dishes_id}")
    Double selectdishesprice(int dishes_id);

    @Select("Select number from dishes where id=#{dishes_id}")
    Integer selectDishesCount(int dishes_id);


    @Update("Update dishes set number =#{count} where id=#{dishes_id}")
    Integer updateDishesCount(int count,int dishes_id);

    @Select("SELECT * FROM order_not_finish where state='未完成' ")
    List<Map<String, Object>> selectOrderNotFinished ();

    @Select("SELECT dishes_id,dishes_count from order_dishes_number where order_id=#{order_id}")
    List<Map<String, Object>> selectOrderDishes (int order_id);

    @Update("Update `order` set state='已完成' where id=#{id}")
    Integer updateOrderState(int id);

    @Insert("insert into dishes (name,price,number,type) values(#{name},#{price},#{number},#{type})")
    Integer insertDishes(String name,Double price,Integer number,Integer type);

    @Delete("delete from dishes where id=#{id}")
    Integer deleteDishes(Integer id);

    @Update("Update dishes set number=#{number} where id=#{id}")
    Integer updateDishes(int id,int number);
}
