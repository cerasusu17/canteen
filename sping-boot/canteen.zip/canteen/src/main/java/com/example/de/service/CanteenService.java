package com.example.de.service;


import java.util.List;
import java.util.Map;

public interface CanteenService {

    List<Map<String,Object>> getDishesInformation(Integer type);

    Integer insertOrder(String time,List<Map<String, Integer>> list);

    List<Map<String,Object>> getOrderUnfin();

    Integer updateOrderState(Integer id);

    Integer insertDishes(String name,Double price,Integer number,Integer type);

    Integer deleteDishes(Integer id);

    Integer updateDishesNumber(Integer id,Integer number);



}
