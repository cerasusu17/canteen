package com.example.de.control;


import com.example.de.service.CanteenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/Canteen", method = { RequestMethod.GET, RequestMethod.POST })
public class CanteenControl {

    @Autowired
    private CanteenService canteenService;

    @Transactional
    @RequestMapping("/DishesList")
    @ResponseBody
    @CrossOrigin
    public List<Map<String, Object>> DishesList(Integer type){
        return canteenService.getDishesInformation(type);
    }

    @Transactional
    @RequestMapping("/OrderDishes")
    @ResponseBody
    @CrossOrigin
    public Integer OrderDishes(@RequestBody Map<String,Object> ob){

        String time=(String)ob.get("time");
        List<Map<String,Integer>> list=(List<Map<String,Integer>>)ob.get("list");
        return canteenService.insertOrder(time,list);
//        return 1;
    }

    @Transactional
    @RequestMapping("/OrderUnfinished")
    @ResponseBody
    @CrossOrigin
    public List<Map<String, Object>> OrderUnfinished(){
        return canteenService.getOrderUnfin();
    }

    @Transactional
    @RequestMapping("/UpdateOrderState")
    @ResponseBody
    @CrossOrigin
    public Integer UpdateOrderState(Integer id){
        return canteenService.updateOrderState(id);
    }

    @Transactional
    @RequestMapping("/InsertDishes")
    @ResponseBody
    @CrossOrigin
    public Integer InsertDishes(String name,Double price,Integer number,Integer type)
    {
        return canteenService.insertDishes(name,price,number,type);
    }

    @Transactional
    @RequestMapping("/DeleteDishes")
    @ResponseBody
    @CrossOrigin
    public Integer DeleteDishes(Integer id){
        return canteenService.deleteDishes(id);
    }


    @Transactional
    @RequestMapping("/UpdateDishes")
    @ResponseBody
    @CrossOrigin
    public Integer UpdateDishes(Integer id,Integer number){
        return canteenService.updateDishesNumber(id,number);
    }
}
