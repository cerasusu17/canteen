package com.example.de.entity;

import lombok.Data;

@Data
public class User {

    private String number;
    private String password;
    private String address;


    private String role;

    public String getNumber() {
        return number;
    }

    public String getAddress() {
        return address;
    }



    public String getRole() {
        return role;
    }

    public String getPassword() {
        return password;
    }
}
