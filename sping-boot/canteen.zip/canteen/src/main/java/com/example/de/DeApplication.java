package com.example.de;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
@MapperScan("com.com.example.de.mapper")
public class DeApplication {

    public static void main(String[] args) {
        SpringApplication.run(DeApplication.class, args);
    }

}
