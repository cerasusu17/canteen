package com.example.de.exception;

public class BusyException extends RuntimeException {
}
