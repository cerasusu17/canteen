package com.example.de.service;

import com.example.de.entity.User;

import java.util.List;
import java.util.Map;

public interface UserService {
//    List<User> findByName(String name);
    int InsertUser(User user);
    List<Map<String, Object>> ListUser();
    int Update(User user);
    int delete(int id);
    Map<String, Object> FindById(int id);
    Map<String,Object>FindNameById(int id);
    Integer getGradeById(int id);
    Map<String,Object> getLevelById(int id);
    List<Map<String,Object>>getCarbonListById(int id);
    Integer setUserGrade(String trip_no);
    List<Map<String,Object>>getRecordById(int id);
    List<Map<String,Object>>getQuestionList();
    void register(String contact,String password,String address);
}
