package com.example.de.exception;

public class NoPasswordException extends RuntimeException {
}
