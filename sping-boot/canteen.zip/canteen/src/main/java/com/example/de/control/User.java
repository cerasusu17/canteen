package com.example.de.control;


import com.example.de.exception.NoPasswordException;
import com.example.de.service.UserService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AccountException;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/CRUD", method = { RequestMethod.GET, RequestMethod.POST })
public class User {

    @Autowired
    private UserService userService;

    //post登录
    @RequestMapping(value = "/login",method = RequestMethod.POST)
    public String login(@RequestParam(value = "contact") String contact, @RequestParam(value = "password") String password){
        //添加用户认证信息
        Subject subject = SecurityUtils.getSubject();
        UsernamePasswordToken usernamePasswordToken = new UsernamePasswordToken(
                contact, password);
        //进行验证，这里可以捕获异常，然后返回对应信息
        try {
            subject.login(usernamePasswordToken);
        } catch (AccountException e) {
         return   "登陆失败";
        }
        return "登陆成功";
    }

    //register注册
    @RequestMapping(value = "/register",method = RequestMethod.POST)
    public String register(@RequestParam(value = "contact") String contact,
                           @RequestParam(value = "password") String password,
                           @RequestParam(value = "address") String address
    ){
        try {
            userService.register(contact,password,address);



        } catch (NoPasswordException e) {
            e.printStackTrace();
            return "手机号已被注册";
        }

        return "注册成功";
    }


}
