package com.example.de.exception;

public class NoTripNoException extends RuntimeException {
}
