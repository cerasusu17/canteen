package com.example.de.exception;

public class NotMinusException extends Exception {
}
