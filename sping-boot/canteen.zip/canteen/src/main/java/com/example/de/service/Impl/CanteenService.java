package com.example.de.service.Impl;


import com.example.de.mapper.CanteenMapper;
import com.example.de.mapper.UserMapper;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import java.util.*;

import com.example.de.entity.User;

@Service
public class CanteenService implements com.example.de.service.CanteenService {

    @Autowired
    private CanteenMapper canteenMapper;

    @Autowired
    private UserMapper userMapper;
//    @Resource
//    private RedisUtil redisUtil;

    public List<Map<String, Object>> getDishesInformation(Integer type) {

//        String key="dishesIdList";
//        if(redisUtil.lGet(key,0,-1).size()==0) {
//            List<Integer> idList = canteenMapper.findDishesId(type);
//            redisUtil.lSet(key, idList);
//
//        }
//        List<Object> idList1=  redisUtil.lGet(key,0,-1);
//
//        List<Map<Object,Object>>dishesInformationList = new ArrayList<Map<Object, Object>>();;
//
//        List<Object>idList2=(List<Object>) idList1.get(0);
//        for (int i=idList2.size()-1;i>=0;i--)
//        {
//
//            Integer id=(Integer) idList2.get(i);
//            Map<Object,Object>map1=redisUtil.hmget(id.toString()+"dishesid");
//            if(map1.size()==0)
//            {
//
//                Map<String,Object>map=canteenMapper.findDishesInformation(id);
//                redisUtil.hmset(id+"dishesid",map);
//            }
//            map1=redisUtil.hmget(id.toString()+"dishesid");
//            dishesInformationList.add(map1);
//
//
//        }

        List<Map<String,Object>> dishesInformationList=canteenMapper.findDishes(type);
        if(dishesInformationList==null||dishesInformationList.size()==0)
            return null;
        for(Map<String,Object>a:dishesInformationList)
        {
            a.put("count",0);
        }
        return dishesInformationList;



//        for (int i=0;i<idList1.size();i++)
//        {
//            List<Object>l=(List<Object>) idList1.get(i);
//        }
//        return null;

//                List<Map<String,Object>>list=canteenMapper.findDishes();
//                return list;

    }

    @Override
    public Integer insertOrder(String time,List<Map<String, Integer>> list) {


      Integer  id=canteenMapper.selectCount()+1;
        String state="未完成";

        Subject subject = SecurityUtils.getSubject();
        String x = (String) subject.getPrincipal();
       User user = userMapper.findUserByNumber(x);
       String number= user.getNumber();
        Double price=0.0;

        for (int i=0;i<list.size();i++)
        {
            Map<String,Integer>map= list.get(i);
            Integer dishes_id=map.get("dishes_id");
            Integer count=map.get("dishes_count");
            price=price+(count*(canteenMapper.selectdishesprice(dishes_id)));
        }

        Integer re=canteenMapper.insertOrder(id,number,time,state,price);
        for (int i=0;i<list.size();i++)
        {
           Map<String,Integer>map= list.get(i);
           Integer dishes_id=map.get("dishes_id");
            Integer count=map.get("dishes_count");
//            redisUtil.del(dishes_id+"dishesid");
           canteenMapper.insertOrderDishes(id,dishes_id,count);
           Integer count1=canteenMapper.selectDishesCount(dishes_id);
           count1=count1-count;
           if(count1>=0) {
               canteenMapper.updateDishesCount(count1, dishes_id);
           }
        }


        return re;

    }

    @Override
    public List<Map<String, Object>> getOrderUnfin() {
        List<Map<String,Object>>list=canteenMapper.selectOrderNotFinished();
        for (int i=0;i<list.size();i++)
        {
            Map<String,Object>map=list.get(i);
            Integer id=(Integer) map.get("id");//获取订单id
            List<Map<String,Object>>disheslist=canteenMapper.selectOrderDishes(id);
            map.put("dishes_list",disheslist);
        }
        return list;
    }

    @Override
    public Integer updateOrderState(Integer id) {
      Integer i=  canteenMapper.updateOrderState(id);
      return i;
    }

    @Override
    public Integer insertDishes(String name, Double price, Integer number, Integer type) {
        Integer i=canteenMapper.insertDishes(name,price,number,type);
        return i;
    }

    @Override
    public Integer deleteDishes(Integer id) {
        Integer i=canteenMapper.deleteDishes(id);
        return i;
    }

    @Override
    public Integer updateDishesNumber(Integer id, Integer number) {
        Integer i=canteenMapper.updateDishes(id,number);
        return i;
    }


}
