package com.example.de.service.Impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.de.exception.NoPasswordException;
import com.example.de.exception.NoTripNoException;
import com.example.de.exception.NoUserIdException;
import com.example.de.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.de.entity.User;
import com.example.de.mapper.UserMapper;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;

//    public List<User> findByName(String name) {
//        return userMapper.findUserByName(name);
//    }

    public int InsertUser(User user) {
      return  userMapper.insertUser(user);

    }

    public  List<Map<String, Object>> ListUser() {
        return userMapper.ListUser();
    }

    public Map<String, Object> FindById(int id) {
        return userMapper.ListUserId(id);
    }

    public int Update(User user) {
        return userMapper.Update(user);
    }

    public int delete(int id) {
        return userMapper.delete(id);
    }

    public Map<String,Object> FindNameById(int id){
        return userMapper.FindNameLikeById(id);
    }

    @Override
    public Integer getGradeById(int id) throws NoUserIdException {
        if(userMapper.GetGradeById(id)==null)
            throw new NoUserIdException();
        else {
            return userMapper.GetGradeById(id);
        }
    }

    @Override
    public  Map<String, Object>getLevelById(int id) {
        Integer i=userMapper.GetGradeById(id);
        if(i==null)
            throw new NoUserIdException();
        else {
            Map<String,Object> m=new HashMap<>();
            if(i<2000) {

                m.put("level", "黄金");
                double z = i / 20;
                m.put("rate", z);
                m.put("next", "铂金");
                return m;
            }
           else
            {
                m.put("level","铂金");
                double z=i/100;
                m.put("rate", z);
                m.put("next", "钻石");
                return m;
            }


        }
    }

    /**
     * 10公里以下：碳排放积分=基础积分6分+金额*1+公里数*0.3
     * 积分12-17
     * 11-30以上：碳排放积分=基础积分8分+金额*1+（公里数-10）*0.1
     * 积分18
     * 31公里以上：碳排放积分=基础分18分
     * @param id
     * @return
     */
    @Override
    public List<Map<String, Object>> getCarbonListById(int id) {
        int get=1;
        List<Map<String, Object>> l = userMapper.GetCarbonListById(id,get);
        if (l.size() == 0)
            throw new NoUserIdException();
        else {
            Double grade;
            int grade1;
            for (Map<String, Object> tmp : l) {
                if ((int) tmp.get("mileage") <= 10) {
                    grade = 6 + (int) tmp.get("amount") + (int) tmp.get("mileage") * 0.3;
                } else if ((int) tmp.get("mileage") <= 30 && (int) tmp.get("mileage") > 10) {
                    grade = 8 + (int) tmp.get("amount") + ((int) tmp.get("mileage") - 10) * 0.1;
                } else {
                    grade = 18.0;
                }
               grade1= grade.intValue();
                tmp.put("grade", grade1);
            }
            return l;
        }
    }

    @Override
    public Integer setUserGrade(String trip_no) {
        int get=1;
        Map<String,Object>m=userMapper.GetCarbonByTripNo(trip_no,get);
        Double grade;
        int grade1;
        if(m==null)
            throw new NoTripNoException() ;
        int id=(int)m.get("user_id");
        if ((int)m.get("mileage") <= 10) {
            grade = 6 + (int) m.get("amount") + (int) m.get("mileage") * 0.3;
        } else if ((int) m.get("mileage") <= 30 && (int) m.get("mileage") > 10) {
            grade = 8 + (int) m.get("amount") + ((int) m.get("mileage") - 10) * 0.1;
        } else {
            grade = 18.0;
        }
        grade1= grade.intValue();
       Integer i=userMapper.SetUserGrade(id,grade1);
       Integer j=userMapper.SetTripGet(trip_no);
       if(i==1&&j==1)
           return 1;
       else
           return 0;

    }

    @Override
    public List<Map<String, Object>> getRecordById(int id) {
        int get=0;
        List<Map<String, Object>> l = userMapper.GetRecordListById(id,get);
        if (l == null)
            throw new NoUserIdException();
        Double grade;
        int grade1;
        for (Map<String, Object> tmp : l) {
            if ((int) tmp.get("mileage") <= 10) {
                grade = 6 + (int) tmp.get("amount") + (int) tmp.get("mileage") * 0.3;
            } else if ((int) tmp.get("mileage") <= 30 && (int) tmp.get("mileage") > 10) {
                grade = 8 + (int) tmp.get("amount") + ((int) tmp.get("mileage") - 10) * 0.1;
            } else {
                grade = 18.0;
            }
            grade1 = grade.intValue();
            tmp.put("grade", grade1);

        }
        return l;
    }

    @Override
    public List<Map<String, Object>> getQuestionList() {
        return userMapper.GetQuestionList();
    }


    @Override
    public void register(String contact, String password,String address) {
        String password1=userMapper.selectPasswordByContact(contact);

        String role="user";
        if(password1==null) {

            userMapper.registerUser(contact, password,address,role);

        }
        else {
            throw new NoPasswordException();
        }
    }


}

