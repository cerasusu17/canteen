package com.example.de.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.*;
import com.example.de.entity.User;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface UserMapper {
 @Select("SELECT * FROM user where name=#{name}")
 User findUserByName(String name);

 @Select("SELECT * from people left join user on people.id=user.id")
 List<Map<String, Object>>  ListUser();

 @Select("SELECT name,password FROM user where id=#{id} ")
 Map<String, Object> ListUserId(int id);
 @Delete("DELETE from user where id=#{id}")
 int delete(int id);
 @Insert(" INSERT INTO user(id,name,password,number)\n" +
         "        VALUES (#{id},#{name, jdbcType=VARCHAR},#{password, jdbcType=VARCHAR},#{number} )")
 int insertUser(User user);

 int Update(User user);
 @Select("SELECT name,'like' FROM test_view where id=#{id}")
 Map<String,Object>FindNameLikeById(int id);

 @Select("SELECT grade from user where user_id=#{id}")
 Integer GetGradeById(int id);

 @Select("Select service_id,out_time,mileage,amount,trip_no from user_has_trip_list where user_id=#{id} and gets=#{get} ")
 List<Map<String,Object>>GetCarbonListById(int id,int get);

 @Update("UPDATE trip SET get = 0 WHERE trip_no =#{trip_no}")
 Integer SetTripGet(String trip_no);

 @Update("UPDATE user set grade=grade+#{grade} where user_id=#{user_id} ")
 Integer SetUserGrade(int user_id,int grade);

 @Select("Select service_id,out_time,mileage,amount,user_id from user_has_trip_list where trip_no=#{trip_no} and gets=#{get} ")
 Map<String,Object>GetCarbonByTripNo(String trip_no,int get);

 @Select("Select service_id,out_time,mileage,amount,trip_no from user_has_trip_list where user_id=#{id} and gets=#{get}  ")
 List<Map<String,Object>>GetRecordListById(int id,int get);

 @Select("Select id,text,A,B,C,D,answer from question")
 List<Map<String,Object>>GetQuestionList();

 @Select("SELECT password from user where number=#{number}")
 String selectPasswordByContact(String number);

 @Select("select * from user where username=#{username}")
 User selectByUsername(@Param("username") String username);

 @Select("select id from user ")
 List<Map<String,Object> >selectId();

 @Insert("INSERT INTO user (number,password,address,role)values(#{number}, #{password},#{address},#{role})")
 Integer registerUser( String number, String password,String address,String role);

 @Select("SELECT * FROM user where number=#{number}")
 User findUserByNumber(String number);
}


